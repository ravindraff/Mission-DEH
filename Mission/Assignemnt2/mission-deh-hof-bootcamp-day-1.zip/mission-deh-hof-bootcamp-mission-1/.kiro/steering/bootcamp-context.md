# Bootcamp Day 1 — Context & Decisions

## Brand
- **Brand:** Sachin Chandrashekhar — Data Engineering Hub
- **Colors:** Primary #1f1840 (dark purple), Secondary #93C572 (green)
- **Footer:** © Sachin Chandrashekhar — Data Engineering Hub. All Rights Reserved.

## Naming Convention
- All AWS resources use prefix: `mission-deh-hof-bootcamp`
- "mission-deh-hof" = Your whole and sole mission should be to crack interviews and win the DEH Hall of Fame award
- Hall of Fame is awarded to those who **crack interviews** (not for completing missions)

## Bootcamp Structure
- **5 Missions** total across the bootcamp
- **Mission 1: Launchpad** (Day 1)
- Day 1 has 3 lab parts + 1 mission + 1 interview prep doc

## Files in This Project
```
bootcamp-instructions-part1.html       Part 1: EC2 Unix Training
bootcamp-instructions-part2.html       Part 2: NYC TLC Database & SQL (Aurora)
bootcamp-instructions-part3.html       Part 3: Glue Crawler & Athena
bootcamp-mission-1-launchpad.html      Mission 1: Launchpad
bootcamp-interview-prep-part1.html     Interview Prep (based on Day 1 services)
mission-deh-hof-ec2-setup.sh
mission-deh-hof-ec2-teardown.sh
mission-deh-hof-nyctlc-db-setup.sh
mission-deh-hof-nyctlc-db-teardown.sh
mission-deh-hof-glue-athena-setup.sh
mission-deh-hof-glue-athena-teardown.sh
```

## AWS Resource Names
### EC2 (Part 1)
- Key pair: `mission-deh-hof-unix-key-bootcamp`
- Security group: `mission-deh-hof-unix-sg-bootcamp`
- Instance: `mission-deh-hof-unix-training-bootcamp`
- IAM role: `mission-deh-hof-unix-role-bootcamp`
- Instance profile: `mission-deh-hof-unix-profile-bootcamp`
- Auto-terminates in 60 minutes

### Aurora (Part 2)
- Cluster: `mission-deh-hof-bootcamp-aurora-cluster`
- Instance: `mission-deh-hof-bootcamp-aurora-instance`
- Security group: `mission-deh-hof-bootcamp-aurora-sg`
- Subnet group: `mission-deh-hof-bootcamp-subnet-group`
- Database: `nyctlc_bootcamp`
- Username: `postgres`
- Password: `DataEngHub2050!`
- Aurora PostgreSQL Serverless v2 (0.5–1.0 ACU)
- HTTP endpoint enabled for Query Editor v2

### Glue/Athena (Part 3)
- S3 bucket: `mission-deh-hof-bootcamp-<ACCOUNT_ID>`
- Folders: `raw/hvfhv/`, `athena-results/`
- IAM role: `mission-deh-hof-bootcamp-glue-role`
- Glue database: `mission_deh_hof_bootcamp`
- Crawler: `mission-deh-hof-bootcamp-hvfhv-crawler`

## NYC TLC Database Schema
Simulates the OLTP system behind NYC taxi trip data.

### Lookup tables
- `vendors` (2 rows) — Creative Mobile Technologies, VeriFone
- `rate_codes` (6 rows) — Standard, JFK, Newark, etc.
- `payment_types` (6 rows) — Credit card, Cash, etc.
- `taxi_zones` (50 zones) — Key NYC zones with borough, zone, service_zone
- `bases` (7 rows) — Uber, Lyft, Via, car services

### Trip tables (20 rows each)
- `yellow_taxi_trips` — tpep timestamps, fare breakdown, congestion surcharge
- `green_taxi_trips` — lpep timestamps, trip_type, similar fare structure
- `fhv_trips` — dispatching_base_num, pickup/dropoff, sr_flag
- `hvfhv_trips` — Uber/Lyft: trip_miles, trip_time, base_passenger_fare, driver_pay, tips, shared/wav flags

## HVFHV Data Source
- NYC TLC portal: `https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_2024-01.parquet`
- Students download to laptop, upload to S3 via console (not CloudShell)
- HV0003 = Uber, HV0005 = Lyft

## Diamond Upsell Wording
- "Silver is about **Information**. Diamond is about **Transformation**."
- "Diamond members get proximity because of shorter group, personalized attention, high accountability and commitment to get you your next high paying AWS Data Engineering job from both sides."
- Waitlist link: https://sachin.cloud/diamond
- "Diamond Membership Opening on Last Day of Bootcamp"
- In interview prep: "Diamond gets you access to discussion of these questions in a small Diamond group setting which will help enhance your knowledge and expertise."

## Mission 1: Launchpad — Structure
### Track A (Required)
1. Share RADE Success Blueprint → post in community
2. Complete "Unix and Cloud Fundamentals" course from LMS → share certificate in community
3. Complete "RDS Cloud Fundamentals" course from LMS → share certificate in community

### Track B (Advanced — only after Track A is done)
4. Complete "Agentic Data Engineering with Amazon Q" course from LMS
5. Build Glue Python Shell job: Aurora → S3 (Parquet, one folder per table)

### Submission
- Create Word doc (.docx) with community post URLs (Track A) + Glue job screenshots (Track B)
- Upload Word doc via Google Form

## HTML Document Style Preferences
- Print/PDF optimized
- No architecture diagrams (keep it simple)
- No "Verify Deployment" tables
- No "What Gets Deleted" / "Billing Model" sections in teardown (just the command + warning)
- All script paths fully qualified from `~/`
- Banners: Yellow (cost warning), Green (video URL), Purple (mission-deh-hof explanation)
- Video URLs are placeholders `[VIDEO_URL — will be provided]`
- Google Form URL is placeholder

## Interview Prep Preferences
- Target audience: 3-4 year experienced AWS Data Engineer (Glue/PySpark focused)
- Drop questions that are DBA/infra/architect level unless DE-relevant
- S3 Select is deprecated (July 2024) — don't include
- Security Group vs NACL is cloud infra, not DE
- EC2 for ETL = almost never (prefer Glue/EMR)
- Diamond inline callouts for: Redshift, Iceberg, Aurora architecture depth
- Key topics for Diamond upsell: Redshift, Iceberg, PySpark advanced, Data Modeling, Orchestration, Real-time, System Design
