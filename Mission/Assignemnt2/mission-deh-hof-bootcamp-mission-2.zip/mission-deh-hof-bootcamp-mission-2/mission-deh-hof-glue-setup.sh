#!/bin/bash
# Copyright © Sachin Chandrashekhar - Data Engineering Hub. All Rights Reserved.
#
# This code is provided as part of a paid training program.
# Unauthorized copying, distribution, or
# publication of this code—either in whole or in part—
# is strictly prohibited.
#
# This code may NOT be:
# - Uploaded to public repositories (GitHub, GitLab, etc.) unless approved by Data Engineering Hub
# - Shared with third parties
# - Used for commercial purposes
#
# Licensed for personal educational use only.
#
# If this code is found on a public repository or distributed without
# authorization, please notify: legal@dataengineeringhub.in
# ============================================================
# DEH Silver Bootcamp - Mission 2 Setup Script
# Creates: S3 bucket, IAM Role for Glue, Glue Databases, Crawlers
# Region: us-east-1
# ============================================================

export AWS_PAGER=""
REGION="us-east-1"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text --no-paginate)
BUCKET_NAME="mission-deh-hof-nyctlc-${ACCOUNT_ID}"
ROLE_NAME="mission-deh-hof-glue-role"
CRAWLER_RAW="mission-deh-hof-crawler-raw"
CRAWLER_CURATED="mission-deh-hof-crawler-curated"
CRAWLER_AGG="mission-deh-hof-crawler-aggregated"

# Log setup
LOG_DIR="$HOME/mission-deh-hof-bootcamp-mission-2/logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/setup-$(date +%Y%m%d-%H%M%S).log"

# Track created resources for rollback
CREATED_RESOURCES=()
SETUP_FAILED=false

log() {
    local msg="[$(date '+%H:%M:%S')] $1"
    echo "$msg"
    echo "$msg" >> "${LOG_FILE}"
}

rollback() {
    log "❌ SETUP FAILED — Rolling back created resources..."
    for resource in "${CREATED_RESOURCES[@]}"; do
        case "$resource" in
            "bucket")
                log "   Rolling back: Deleting S3 bucket ${BUCKET_NAME}..."
                aws s3 rb "s3://${BUCKET_NAME}" --force --no-paginate > /dev/null 2>&1 || true
                ;;
            "role")
                log "   Rolling back: Deleting IAM role ${ROLE_NAME}..."
                aws iam detach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole --no-paginate > /dev/null 2>&1 || true
                aws iam detach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess --no-paginate > /dev/null 2>&1 || true
                aws iam detach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess --no-paginate > /dev/null 2>&1 || true
                aws iam delete-role --role-name ${ROLE_NAME} --no-paginate > /dev/null 2>&1 || true
                ;;
            "db_raw")
                aws glue delete-database --name "nyctlc_raw" --no-paginate > /dev/null 2>&1 || true
                ;;
            "db_curated")
                aws glue delete-database --name "nyctlc_curated" --no-paginate > /dev/null 2>&1 || true
                ;;
            "db_aggregated")
                aws glue delete-database --name "nyctlc_aggregated" --no-paginate > /dev/null 2>&1 || true
                ;;
            "crawler_raw")
                aws glue delete-crawler --name ${CRAWLER_RAW} --no-paginate > /dev/null 2>&1 || true
                ;;
            "crawler_curated")
                aws glue delete-crawler --name ${CRAWLER_CURATED} --no-paginate > /dev/null 2>&1 || true
                ;;
            "crawler_agg")
                aws glue delete-crawler --name ${CRAWLER_AGG} --no-paginate > /dev/null 2>&1 || true
                ;;
        esac
    done
    log "   Rollback complete."
    log "   Log file: ${LOG_FILE}"
    exit 1
}

log "============================================================"
log "  🚀 DEH Bootcamp Mission 2 — Glue Pipeline Setup"
log "============================================================"
log ""
log "📋 Configuration:"
log "   Account ID:  ${ACCOUNT_ID}"
log "   Region:      ${REGION}"
log "   S3 Bucket:   ${BUCKET_NAME}"
log "   Glue Role:   ${ROLE_NAME}"
log "   Log file:    ${LOG_FILE}"
log ""

# ---------------------------------------------------------
# Step 1: Create S3 Bucket
# ---------------------------------------------------------
log "📦 Step 1: Creating S3 bucket..."
if aws s3api head-bucket --bucket "${BUCKET_NAME}" --no-paginate > /dev/null 2>&1; then
    log "   ⚠️  Bucket already exists. Proceeding."
else
    if aws s3 mb "s3://${BUCKET_NAME}" --region ${REGION} --no-paginate > /dev/null 2>&1; then
        CREATED_RESOURCES+=("bucket")
        log "   ✅ Bucket created: ${BUCKET_NAME}"
    else
        log "   ❌ Failed to create bucket."
        SETUP_FAILED=true
        rollback
    fi
fi

# Create folder structure
log "   Creating folder structure..."
aws s3api put-object --bucket ${BUCKET_NAME} --key "raw/nyctlc/fhvhv_tripdata/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "raw/nyctlc/taxi_zone_lookup/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "curated/nyctlc/fhvhv_trips_curated/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "aggregated/nyctlc/daily_borough_summary/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "aggregated/nyctlc/hourly_pattern_summary/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "aggregated/nyctlc/route_summary/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
aws s3api put-object --bucket ${BUCKET_NAME} --key "athena-results/" --content-length 0 --no-paginate > /dev/null 2>&1 || true
log "   ✅ Folder structure created."

# ---------------------------------------------------------
# Step 2: Create IAM Role for Glue
# ---------------------------------------------------------
log ""
log "🔐 Step 2: Creating IAM Role for Glue..."

TRUST_POLICY='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"glue.amazonaws.com"},"Action":"sts:AssumeRole"}]}'

if aws iam get-role --role-name ${ROLE_NAME} --no-paginate > /dev/null 2>&1; then
    log "   ⚠️  Role already exists. Ensuring policies are attached..."
else
    if aws iam create-role --role-name ${ROLE_NAME} --assume-role-policy-document "${TRUST_POLICY}" --description "Glue role for DEH Bootcamp Mission 2" --no-paginate > /dev/null 2>&1; then
        CREATED_RESOURCES+=("role")
        log "   ⏳ Waiting for IAM role to propagate (10 seconds)..."
        sleep 10
        log "   ✅ Role created."
    else
        log "   ❌ Failed to create IAM role."
        SETUP_FAILED=true
        rollback
    fi
fi

# Always ensure policies are attached (idempotent)
aws iam attach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole --no-paginate > /dev/null 2>&1 || true
aws iam attach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess --no-paginate > /dev/null 2>&1 || true
aws iam attach-role-policy --role-name ${ROLE_NAME} --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess --no-paginate > /dev/null 2>&1 || true

# Add PassRole permission (required for Glue notebooks to pass the role to themselves)
PASSROLE_POLICY="{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Action\":\"iam:PassRole\",\"Resource\":\"arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}\"}]}"
aws iam put-role-policy --role-name ${ROLE_NAME} --policy-name "GluePassRolePolicy" --policy-document "${PASSROLE_POLICY}" --no-paginate > /dev/null 2>&1 || true

log "   ✅ Policies attached."

ROLE_ARN=$(aws iam get-role --role-name ${ROLE_NAME} --query 'Role.Arn' --output text --no-paginate 2>/dev/null)

# ---------------------------------------------------------
# Step 3: Create Glue Databases
# ---------------------------------------------------------
log ""
log "🗄️  Step 3: Creating Glue Catalog databases..."

for DB_NAME in "nyctlc_raw" "nyctlc_curated" "nyctlc_aggregated"; do
    if aws glue get-database --name ${DB_NAME} --no-paginate > /dev/null 2>&1; then
        log "   ⚠️  Database ${DB_NAME} already exists. Proceeding."
    else
        if aws glue create-database --database-input "{\"Name\": \"${DB_NAME}\", \"Description\": \"DEH Bootcamp Mission 2 - ${DB_NAME}\"}" --no-paginate > /dev/null 2>&1; then
            CREATED_RESOURCES+=("db_${DB_NAME#nyctlc_}")
            log "   ✅ Created database: ${DB_NAME}"
        else
            log "   ❌ Failed to create database: ${DB_NAME}"
            SETUP_FAILED=true
            rollback
        fi
    fi
done

# ---------------------------------------------------------
# Step 4: Create Glue Crawlers
# ---------------------------------------------------------
log ""
log "🕷️  Step 4: Creating Glue Crawlers..."

if aws glue get-crawler --name ${CRAWLER_RAW} --no-paginate > /dev/null 2>&1; then
    log "   ⚠️  Crawler ${CRAWLER_RAW} already exists. Proceeding."
else
    if aws glue create-crawler --name ${CRAWLER_RAW} --role ${ROLE_ARN} --database-name "nyctlc_raw" \
        --targets "{\"S3Targets\": [{\"Path\": \"s3://${BUCKET_NAME}/raw/nyctlc/fhvhv_tripdata/\"}, {\"Path\": \"s3://${BUCKET_NAME}/raw/nyctlc/taxi_zone_lookup/\"}]}" \
        --schema-change-policy "{\"UpdateBehavior\": \"UPDATE_IN_DATABASE\", \"DeleteBehavior\": \"LOG\"}" \
        --region ${REGION} --no-paginate > /dev/null 2>&1; then
        CREATED_RESOURCES+=("crawler_raw")
        log "   ✅ Created crawler: ${CRAWLER_RAW}"
    else
        log "   ❌ Failed to create crawler: ${CRAWLER_RAW}"
        SETUP_FAILED=true
        rollback
    fi
fi

if aws glue get-crawler --name ${CRAWLER_CURATED} --no-paginate > /dev/null 2>&1; then
    log "   ⚠️  Crawler ${CRAWLER_CURATED} already exists. Proceeding."
else
    if aws glue create-crawler --name ${CRAWLER_CURATED} --role ${ROLE_ARN} --database-name "nyctlc_curated" \
        --targets "{\"S3Targets\": [{\"Path\": \"s3://${BUCKET_NAME}/curated/nyctlc/fhvhv_trips_curated/\"}]}" \
        --schema-change-policy "{\"UpdateBehavior\": \"UPDATE_IN_DATABASE\", \"DeleteBehavior\": \"LOG\"}" \
        --region ${REGION} --no-paginate > /dev/null 2>&1; then
        CREATED_RESOURCES+=("crawler_curated")
        log "   ✅ Created crawler: ${CRAWLER_CURATED}"
    else
        log "   ❌ Failed to create crawler: ${CRAWLER_CURATED}"
        SETUP_FAILED=true
        rollback
    fi
fi

if aws glue get-crawler --name ${CRAWLER_AGG} --no-paginate > /dev/null 2>&1; then
    log "   ⚠️  Crawler ${CRAWLER_AGG} already exists. Proceeding."
else
    if aws glue create-crawler --name ${CRAWLER_AGG} --role ${ROLE_ARN} --database-name "nyctlc_aggregated" \
        --targets "{\"S3Targets\": [{\"Path\": \"s3://${BUCKET_NAME}/aggregated/nyctlc/daily_borough_summary/\"}, {\"Path\": \"s3://${BUCKET_NAME}/aggregated/nyctlc/hourly_pattern_summary/\"}, {\"Path\": \"s3://${BUCKET_NAME}/aggregated/nyctlc/route_summary/\"}]}" \
        --schema-change-policy "{\"UpdateBehavior\": \"UPDATE_IN_DATABASE\", \"DeleteBehavior\": \"LOG\"}" \
        --region ${REGION} --no-paginate > /dev/null 2>&1; then
        CREATED_RESOURCES+=("crawler_agg")
        log "   ✅ Created crawler: ${CRAWLER_AGG}"
    else
        log "   ❌ Failed to create crawler: ${CRAWLER_AGG}"
        SETUP_FAILED=true
        rollback
    fi
fi

# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------
log ""
log "============================================================"
log "  ✅ SETUP COMPLETE!"
log "============================================================"
log ""
log "  S3 Bucket:     ${BUCKET_NAME}"
log "  IAM Role:      ${ROLE_NAME}"
log "  Region:        ${REGION}"
log ""
log "  Glue Crawlers:"
log "    ${CRAWLER_RAW}        → nyctlc_raw"
log "    ${CRAWLER_CURATED}    → nyctlc_curated"
log "    ${CRAWLER_AGG}  → nyctlc_aggregated"
log ""
log "  Athena Results: s3://${BUCKET_NAME}/athena-results/"
log "  Log file:      ${LOG_FILE}"
log ""
log "  Next: Open bootcamp-mission2-part1-ingestion.html"
log "============================================================"
