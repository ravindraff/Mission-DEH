# Copyright © Sachin Chandrashekhar - Data Engineering Hub. All Rights Reserved.
#
# This code is provided as part of a paid training program.
# Unauthorized copying, distribution, or
# publication of this code—either in whole or in part—
# is strictly prohibited.
#
# This code may NOT be:
# - Uploaded to public repositories (GitHub, GitLab, etc.) unless approved by Data Engineering Hub
# - Shared with third parties
# - Used for commercial purposes
#
# Licensed for personal educational use only.
#
# If this code is found on a public repository or distributed without
# authorization, please notify: legal@dataengineeringhub.in

"""
AWS Glue Python Shell - NYCTLC Lyft (HVFHV) Data Ingestion
================================================================
Backup script for DEH Silver Bootcamp Mission 2.
Downloads the latest NYCTLC HVFHV (High Volume For-Hire Vehicle) parquet file
and taxi zone lookup from CloudFront and uploads to S3 raw layer.

Usage: Deploy as a Glue Python Shell job. Bucket name is auto-detected from account ID.
"""

import sys
import requests
import boto3
from datetime import datetime, timedelta

# ---------------------------------------------------------
# Configuration — update with your bucket name
# ---------------------------------------------------------
ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
BUCKET_NAME = f"mission-deh-hof-nyctlc-{ACCOUNT_ID}"

# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------
CLOUDFRONT_BASE = "https://d37ci6vzurychx.cloudfront.net"
TRIP_DATA_PATH = "/trip-data/fhvhv_tripdata_{year}-{month:02d}.parquet"
ZONE_LOOKUP_URL = f"{CLOUDFRONT_BASE}/misc/taxi+_zone_lookup.csv"

S3_RAW_TRIP_PREFIX = "raw/nyctlc/fhvhv_tripdata/"
S3_RAW_ZONE_PREFIX = "raw/nyctlc/taxi_zone_lookup/"

s3_client = boto3.client('s3')


def find_latest_available_month():
    """
    NYCTLC data is typically available ~2 months after the trip month.
    Try current month minus 2, then minus 3, then minus 4.
    """
    today = datetime.now()
    
    for months_back in [2, 3, 4]:
        target_date = today - timedelta(days=30 * months_back)
        year = target_date.year
        month = target_date.month
        
        url = f"{CLOUDFRONT_BASE}{TRIP_DATA_PATH.format(year=year, month=month)}"
        print(f"Checking availability: {url}")
        
        response = requests.head(url, timeout=10)
        if response.status_code == 200:
            print(f"✅ Found available data: {year}-{month:02d}")
            return year, month, url
        else:
            print(f"❌ Not available (HTTP {response.status_code}): {year}-{month:02d}")
    
    raise Exception("Could not find available NYCTLC HVFHV data for recent months!")


def download_and_upload(source_url, s3_key, stream=False):
    """Download file from URL and upload to S3. Uses streaming multipart upload for large files."""
    print(f"⬇️  Downloading: {source_url}")

    if not stream:
        # Small files — download fully into memory
        response = requests.get(source_url, timeout=300)
        response.raise_for_status()
        file_size_mb = len(response.content) / (1024 * 1024)
        print(f"   Downloaded: {file_size_mb:.1f} MB")

        print(f"⬆️  Uploading to: s3://{BUCKET_NAME}/{s3_key}")
        s3_client.put_object(Bucket=BUCKET_NAME, Key=s3_key, Body=response.content)
        print(f"   ✅ Upload complete!")
    else:
        # Large files — stream in chunks via S3 multipart upload
        CHUNK_SIZE = 10 * 1024 * 1024  # 10 MB

        response = requests.get(source_url, timeout=300, stream=True)
        response.raise_for_status()

        content_length = response.headers.get("Content-Length", "unknown")
        print(f"   File size: {content_length} bytes")

        mpu = s3_client.create_multipart_upload(Bucket=BUCKET_NAME, Key=s3_key)
        upload_id = mpu["UploadId"]

        parts = []
        part_number = 1
        downloaded = 0
        buffer = b""

        try:
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if chunk:
                    buffer += chunk
                    downloaded += len(chunk)

                    if len(buffer) >= CHUNK_SIZE:
                        print(f"   Uploading part {part_number} ({downloaded / (1024*1024):.1f} MB downloaded)...")
                        part = s3_client.upload_part(
                            Bucket=BUCKET_NAME,
                            Key=s3_key,
                            PartNumber=part_number,
                            UploadId=upload_id,
                            Body=buffer
                        )
                        parts.append({"PartNumber": part_number, "ETag": part["ETag"]})
                        part_number += 1
                        buffer = b""

            # Upload remaining buffer
            if buffer:
                print(f"   Uploading final part {part_number} ({downloaded / (1024*1024):.1f} MB total)...")
                part = s3_client.upload_part(
                    Bucket=BUCKET_NAME,
                    Key=s3_key,
                    PartNumber=part_number,
                    UploadId=upload_id,
                    Body=buffer
                )
                parts.append({"PartNumber": part_number, "ETag": part["ETag"]})

            s3_client.complete_multipart_upload(
                Bucket=BUCKET_NAME,
                Key=s3_key,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts}
            )
            print(f"   ✅ Upload complete: s3://{BUCKET_NAME}/{s3_key}")

        except Exception as e:
            print(f"   ❌ Error during upload, aborting: {e}")
            s3_client.abort_multipart_upload(Bucket=BUCKET_NAME, Key=s3_key, UploadId=upload_id)
            raise


def main():
    print("=" * 60)
    print("NYCTLC Lyft (HVFHV) Data Ingestion")
    print(f"Target bucket: {BUCKET_NAME}")
    print("=" * 60)
    
    # Step 1: Find and download latest trip data
    print("\n📦 Step 1: Finding latest available HVFHV trip data...")
    year, month, trip_url = find_latest_available_month()
    
    trip_filename = f"fhvhv_tripdata_{year}-{month:02d}.parquet"
    trip_s3_key = f"{S3_RAW_TRIP_PREFIX}{trip_filename}"
    
    download_and_upload(trip_url, trip_s3_key, stream=True)
    
    # Step 2: Download taxi zone lookup
    print("\n📦 Step 2: Downloading taxi zone lookup table...")
    zone_s3_key = f"{S3_RAW_ZONE_PREFIX}taxi_zone_lookup.csv"
    
    download_and_upload(ZONE_LOOKUP_URL, zone_s3_key)
    
    # Summary
    print("\n" + "=" * 60)
    print("✅ INGESTION COMPLETE!")
    print(f"   Trip data: s3://{BUCKET_NAME}/{trip_s3_key}")
    print(f"   Zone lookup: s3://{BUCKET_NAME}/{zone_s3_key}")
    print("=" * 60)


if __name__ == "__main__":
    main()
