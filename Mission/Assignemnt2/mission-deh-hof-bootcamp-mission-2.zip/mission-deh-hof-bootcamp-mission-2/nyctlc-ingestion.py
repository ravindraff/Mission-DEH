"""
AWS Glue Python Shell Job: NYCTLC HVFHV Data Ingestion
Downloads the latest available HVFHV parquet file and taxi zone lookup CSV,
then uploads both to S3 in the raw layer.
"""

import sys
import boto3
import requests
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
sts_client = boto3.client("sts")
ACCOUNT_ID = sts_client.get_caller_identity()["Account"]
BUCKET_NAME = f"mission-deh-hof-nyctlc-{ACCOUNT_ID}"

TRIP_DATA_PREFIX = "raw/nyctlc/fhvhv_tripdata/"
ZONE_LOOKUP_PREFIX = "raw/nyctlc/taxi_zone_lookup/"

TRIP_DATA_BASE_URL = "https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_{}.parquet"
ZONE_LOOKUP_URL = "https://d37ci6vzurychx.cloudfront.net/misc/taxi+_zone_lookup.csv"

CHUNK_SIZE = 10 * 1024 * 1024  # 10 MB chunks for streaming download

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def find_latest_trip_file():
    """
    Try current month minus 2, minus 3, minus 4, etc. until we find a file
    that returns HTTP 200. Returns the URL and filename on success.
    """
    now = datetime.utcnow()
    
    for months_back in range(2, 5):
        # Calculate target month
        target_date = datetime(now.year, now.month, 1) - timedelta(days=months_back * 30)
        year_month = target_date.strftime("%Y-%m")
        url = TRIP_DATA_BASE_URL.format(year_month)
        filename = f"fhvhv_tripdata_{year_month}.parquet"
        
        print(f"Checking availability: {url}")
        response = requests.head(url, allow_redirects=True)
        
        if response.status_code == 200:
            print(f"Found available file: {filename}")
            return url, filename
        else:
            print(f"  Not available (HTTP {response.status_code}), trying next...")
    
    print("ERROR: No available HVFHV trip data file found.")
    sys.exit(1)


def streaming_download_to_s3(url, bucket, s3_key):
    """
    Downloads a file via streaming and uploads it to S3 using multipart upload.
    Suitable for large files (300-400 MB).
    """
    s3_client = boto3.client("s3")
    
    print(f"Starting streaming download: {url}")
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    content_length = response.headers.get("Content-Length", "unknown")
    print(f"File size: {content_length} bytes")
    
    # Use multipart upload for large files
    mpu = s3_client.create_multipart_upload(Bucket=bucket, Key=s3_key)
    upload_id = mpu["UploadId"]
    
    parts = []
    part_number = 1
    downloaded = 0
    buffer = b""
    
    try:
        for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
            if chunk:
                buffer += chunk
                downloaded += len(chunk)
                
                # Upload part when buffer reaches chunk size
                if len(buffer) >= CHUNK_SIZE:
                    print(f"  Uploading part {part_number} ({downloaded / (1024*1024):.1f} MB downloaded)...")
                    part = s3_client.upload_part(
                        Bucket=bucket,
                        Key=s3_key,
                        PartNumber=part_number,
                        UploadId=upload_id,
                        Body=buffer
                    )
                    parts.append({"PartNumber": part_number, "ETag": part["ETag"]})
                    part_number += 1
                    buffer = b""
        
        # Upload remaining buffer
        if buffer:
            print(f"  Uploading final part {part_number} ({downloaded / (1024*1024):.1f} MB total)...")
            part = s3_client.upload_part(
                Bucket=bucket,
                Key=s3_key,
                PartNumber=part_number,
                UploadId=upload_id,
                Body=buffer
            )
            parts.append({"PartNumber": part_number, "ETag": part["ETag"]})
        
        # Complete the multipart upload
        s3_client.complete_multipart_upload(
            Bucket=bucket,
            Key=s3_key,
            UploadId=upload_id,
            MultipartUpload={"Parts": parts}
        )
        print(f"Upload complete: s3://{bucket}/{s3_key}")
        
    except Exception as e:
        print(f"ERROR during upload, aborting multipart upload: {e}")
        s3_client.abort_multipart_upload(Bucket=bucket, Key=s3_key, UploadId=upload_id)
        raise


def upload_small_file_to_s3(url, bucket, s3_key):
    """
    Downloads a small file and uploads directly to S3.
    """
    s3_client = boto3.client("s3")
    
    print(f"Downloading: {url}")
    response = requests.get(url)
    response.raise_for_status()
    print(f"  Downloaded {len(response.content)} bytes")
    
    print(f"Uploading to s3://{bucket}/{s3_key}")
    s3_client.put_object(Bucket=bucket, Key=s3_key, Body=response.content)
    print(f"  Upload complete.")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 60)
    print("NYCTLC HVFHV Data Ingestion - Starting")
    print(f"Target bucket: {BUCKET_NAME}")
    print("=" * 60)
    
    # Step 1: Find the latest available HVFHV trip data file
    print("\n--- Step 1: Finding latest available HVFHV trip data file ---")
    trip_url, trip_filename = find_latest_trip_file()
    
    # Step 2: Download and upload trip data (streaming for large file)
    print("\n--- Step 2: Downloading and uploading trip data to S3 ---")
    trip_s3_key = f"{TRIP_DATA_PREFIX}{trip_filename}"
    streaming_download_to_s3(trip_url, BUCKET_NAME, trip_s3_key)
    
    # Step 3: Download and upload taxi zone lookup CSV
    print("\n--- Step 3: Downloading and uploading taxi zone lookup ---")
    zone_s3_key = f"{ZONE_LOOKUP_PREFIX}taxi_zone_lookup.csv"
    upload_small_file_to_s3(ZONE_LOOKUP_URL, BUCKET_NAME, zone_s3_key)
    
    print("\n" + "=" * 60)
    print("NYCTLC HVFHV Data Ingestion - Complete")
    print("=" * 60)


if __name__ == "__main__":
    main()
