# Copyright © Sachin Chandrashekhar - Data Engineering Hub. All Rights Reserved.
#
# This code is provided as part of a paid training program.
# Unauthorized copying, distribution, or
# publication of this code—either in whole or in part—
# is strictly prohibited.
#
# This code may NOT be:
# - Uploaded to public repositories (GitHub, GitLab, etc.) unless approved by Data Engineering Hub
# - Shared with third parties
# - Used for commercial purposes
#
# Licensed for personal educational use only.
#
# If this code is found on a public repository or distributed without
# authorization, please notify: legal@dataengineeringhub.in

"""
AWS Glue ETL - Curated to Aggregated Transformation
====================================================
Backup script for DEH Silver Bootcamp Mission 2.
Reads curated NYCTLC Lyft data and produces 3 aggregate tables:
1. Daily Borough Summary
2. Hourly Pattern Summary
3. Route Summary

Usage: Deploy as Glue ETL (Spark) job. Bucket name is auto-detected from account ID.
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import (
    col, count, sum as spark_sum, avg, round as spark_round, when
)
import boto3

# ---------------------------------------------------------
# Glue Job Init
# ---------------------------------------------------------
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
BUCKET = f"mission-deh-hof-nyctlc-{ACCOUNT_ID}"

print("=" * 60)
print("CURATED TO AGGREGATED TRANSFORMATION — Lyft")
print(f"Bucket: {BUCKET}")
print("=" * 60)

# ---------------------------------------------------------
# Read Curated Data
# ---------------------------------------------------------
print("\n📦 Reading curated HVFHV data...")
curated_df = spark.read.parquet(f"s3://{BUCKET}/curated/nyctlc/fhvhv_trips_curated/")
total_records = curated_df.count()
print(f"   Curated records: {total_records:,}")

# ---------------------------------------------------------
# Aggregate 1: Daily Borough Summary
# ---------------------------------------------------------
print("\n📊 Aggregate 1: Daily Borough Summary...")

daily_borough = curated_df.groupBy("pickup_date", "pickup_borough").agg(
    count("*").alias("total_trips"),
    spark_round(spark_sum("base_passenger_fare"), 2).alias("total_revenue"),
    spark_round(avg("base_passenger_fare"), 2).alias("avg_fare"),
    spark_round(avg("tips"), 2).alias("avg_tip"),
    spark_round(avg("trip_miles"), 2).alias("avg_trip_miles"),
    spark_round(avg("trip_duration_minutes"), 2).alias("avg_trip_duration_minutes"),
    spark_round(avg("speed_mph"), 2).alias("avg_speed_mph")
)

output_1 = f"s3://{BUCKET}/aggregated/nyctlc/daily_borough_summary/"
daily_borough.write.mode("overwrite") \
    .partitionBy("pickup_date") \
    .parquet(output_1)

print(f"   ✅ Written: {daily_borough.count():,} rows → {output_1}")

# ---------------------------------------------------------
# Aggregate 2: Hourly Pattern Summary
# ---------------------------------------------------------
print("\n📊 Aggregate 2: Hourly Pattern Summary...")

hourly_pattern = curated_df.groupBy("pickup_hour", "is_weekend", "pickup_borough").agg(
    count("*").alias("total_trips"),
    spark_round(avg("base_passenger_fare"), 2).alias("avg_fare"),
    spark_round(avg("trip_miles"), 2).alias("avg_trip_miles"),
    spark_round(avg(
        when(col("base_passenger_fare") > 0, col("tips") / col("base_passenger_fare") * 100)
    ), 2).alias("avg_tip_percentage"),
    spark_round(avg("speed_mph"), 2).alias("avg_speed_mph"),
    spark_round(avg("wait_time_minutes"), 2).alias("avg_wait_time_minutes")
)

output_2 = f"s3://{BUCKET}/aggregated/nyctlc/hourly_pattern_summary/"
hourly_pattern.write.mode("overwrite") \
    .parquet(output_2)

print(f"   ✅ Written: {hourly_pattern.count():,} rows → {output_2}")

# ---------------------------------------------------------
# Aggregate 3: Route Summary
# ---------------------------------------------------------
print("\n📊 Aggregate 3: Route Summary...")

route_summary = curated_df.groupBy(
    "pickup_borough", "pickup_zone", "dropoff_borough", "dropoff_zone"
).agg(
    count("*").alias("total_trips"),
    spark_round(avg("base_passenger_fare"), 2).alias("avg_fare"),
    spark_round(avg("trip_miles"), 2).alias("avg_trip_miles"),
    spark_round(avg("trip_duration_minutes"), 2).alias("avg_trip_duration_minutes")
).filter(col("total_trips") >= 10)

output_3 = f"s3://{BUCKET}/aggregated/nyctlc/route_summary/"
route_summary.write.mode("overwrite") \
    .parquet(output_3)

print(f"   ✅ Written: {route_summary.count():,} rows → {output_3}")

# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------
print("\n" + "=" * 60)
print("✅ CURATED TO AGGREGATED COMPLETE!")
print(f"   Input:  {total_records:,} curated records")
print(f"   Output: 3 aggregate tables written to s3://{BUCKET}/aggregated/")
print("   Tables:")
print(f"     1. daily_borough_summary → {output_1}")
print(f"     2. hourly_pattern_summary → {output_2}")
print(f"     3. route_summary → {output_3}")
print("=" * 60)

job.commit()
