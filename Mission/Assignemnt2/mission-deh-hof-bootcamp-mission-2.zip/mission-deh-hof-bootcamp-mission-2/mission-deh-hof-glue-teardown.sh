#!/bin/bash
# Copyright © Sachin Chandrashekhar - Data Engineering Hub. All Rights Reserved.
#
# This code is provided as part of a paid training program.
# Unauthorized copying, distribution, or
# publication of this code—either in whole or in part—
# is strictly prohibited.
#
# This code may NOT be:
# - Uploaded to public repositories (GitHub, GitLab, etc.) unless approved by Data Engineering Hub
# - Shared with third parties
# - Used for commercial purposes
#
# Licensed for personal educational use only.
#
# If this code is found on a public repository or distributed without
# authorization, please notify: legal@dataengineeringhub.in
# ============================================================
# DEH Silver Bootcamp - Mission 2 Teardown Script
# Removes: Glue jobs, Crawlers, Databases, S3 bucket, IAM Role
# Region: us-east-1
# ============================================================

export AWS_PAGER=""
REGION="us-east-1"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text --no-paginate)
BUCKET_NAME="mission-deh-hof-nyctlc-${ACCOUNT_ID}"
ROLE_NAME="mission-deh-hof-glue-role"

# Log setup
LOG_DIR="$HOME/mission-deh-hof-bootcamp-mission-2/logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/teardown-$(date +%Y%m%d-%H%M%S).log"

log() {
    local msg="[$(date '+%H:%M:%S')] $1"
    echo "$msg"
    echo "$msg" >> "${LOG_FILE}"
}

log "============================================================"
log "  🧹 DEH Bootcamp Mission 2 — Teardown"
log "============================================================"
log ""
log "📋 Will remove all mission-deh-hof resources"
log "   Log file: ${LOG_FILE}"
log ""

# ---------------------------------------------------------
# Step 1: Delete Glue Jobs
# ---------------------------------------------------------
log "🗑️  Step 1: Deleting Glue jobs..."
for JOB_NAME in "mission-deh-hof-nyctlc-ingestion" "mission-deh-hof-raw-to-curated-etl" "mission-deh-hof-curated-to-aggregated-etl"; do
    if aws glue get-job --job-name ${JOB_NAME} --no-paginate > /dev/null 2>&1; then
        aws glue delete-job --job-name ${JOB_NAME} --no-paginate > /dev/null 2>&1 || true
        log "   ✅ Deleted job: ${JOB_NAME}"
    else
        log "   ⚠️  Job not found: ${JOB_NAME} (skipping)"
    fi
done

# ---------------------------------------------------------
# Step 2: Delete Glue Crawlers
# ---------------------------------------------------------
log ""
log "🗑️  Step 2: Deleting Glue crawlers..."
for CRAWLER_NAME in "mission-deh-hof-crawler-raw" "mission-deh-hof-crawler-curated" "mission-deh-hof-crawler-aggregated"; do
    if aws glue get-crawler --name ${CRAWLER_NAME} --no-paginate > /dev/null 2>&1; then
        aws glue delete-crawler --name ${CRAWLER_NAME} --no-paginate > /dev/null 2>&1 || true
        log "   ✅ Deleted crawler: ${CRAWLER_NAME}"
    else
        log "   ⚠️  Crawler not found: ${CRAWLER_NAME} (skipping)"
    fi
done

# ---------------------------------------------------------
# Step 3: Delete Glue Databases (and all tables within)
# ---------------------------------------------------------
log ""
log "🗑️  Step 3: Deleting Glue databases..."
for DB_NAME in "nyctlc_raw" "nyctlc_curated" "nyctlc_aggregated"; do
    if aws glue get-database --name ${DB_NAME} --no-paginate > /dev/null 2>&1; then
        TABLES=$(aws glue get-tables --database-name ${DB_NAME} --query 'TableList[].Name' --output text --no-paginate 2>/dev/null || echo "")
        for TABLE_NAME in ${TABLES}; do
            aws glue delete-table --database-name ${DB_NAME} --name ${TABLE_NAME} --no-paginate > /dev/null 2>&1 || true
        done
        aws glue delete-database --name ${DB_NAME} --no-paginate > /dev/null 2>&1 || true
        log "   ✅ Deleted database: ${DB_NAME}"
    else
        log "   ⚠️  Database not found: ${DB_NAME} (skipping)"
    fi
done

# ---------------------------------------------------------
# Step 4: Delete S3 Bucket (all contents)
# ---------------------------------------------------------
log ""
log "🗑️  Step 4: Deleting S3 bucket and contents..."
if aws s3api head-bucket --bucket "${BUCKET_NAME}" --no-paginate > /dev/null 2>&1; then
    aws s3 rb "s3://${BUCKET_NAME}" --force --no-paginate > /dev/null 2>&1 || true
    log "   ✅ Bucket deleted: ${BUCKET_NAME}"
else
    log "   ⚠️  Bucket not found (skipping)"
fi

# ---------------------------------------------------------
# Step 5: Delete IAM Role
# ---------------------------------------------------------
log ""
log "🗑️  Step 5: Deleting IAM role..."
if aws iam get-role --role-name ${ROLE_NAME} --no-paginate > /dev/null 2>&1; then
    POLICIES=$(aws iam list-attached-role-policies --role-name ${ROLE_NAME} --query 'AttachedPolicies[].PolicyArn' --output text --no-paginate 2>/dev/null || echo "")
    for POLICY_ARN in ${POLICIES}; do
        aws iam detach-role-policy --role-name ${ROLE_NAME} --policy-arn ${POLICY_ARN} --no-paginate > /dev/null 2>&1 || true
    done
    INLINE_POLICIES=$(aws iam list-role-policies --role-name ${ROLE_NAME} --query 'PolicyNames[]' --output text --no-paginate 2>/dev/null || echo "")
    for POLICY_NAME in ${INLINE_POLICIES}; do
        aws iam delete-role-policy --role-name ${ROLE_NAME} --policy-name ${POLICY_NAME} --no-paginate > /dev/null 2>&1 || true
    done
    aws iam delete-role --role-name ${ROLE_NAME} --no-paginate > /dev/null 2>&1 || true
    log "   ✅ Role deleted: ${ROLE_NAME}"
else
    log "   ⚠️  Role not found (skipping)"
fi

# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------
log ""
log "============================================================"
log "  ✅ TEARDOWN COMPLETE!"
log "============================================================"
log ""
log "  All mission-deh-hof resources have been removed."
log "  Note: Glue jobs and Lambda cost nothing at rest."
log "  The main cost-bearing resource (S3 data) has been deleted."
log ""
log "  Log file: ${LOG_FILE}"
log "============================================================"
